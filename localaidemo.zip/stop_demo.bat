@echo off
echo Shutting down Local AI Demo Stack...
echo.

echo Stopping Foundry Local service...
foundry service stop

echo Killing any remaining Python processes (demo app + keepalive)...
taskkill /F /IM python.exe >nul 2>&1

echo Killing Open WebUI if still running...
taskkill /F /FI "WINDOWTITLE eq Open WebUI 3000" >nul 2>&1

echo.
echo =============================================
echo   All services stopped. Resources freed.
echo =============================================
echo.
pause
