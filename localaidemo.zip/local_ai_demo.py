"""
Local AI Demo — TD SYNNEX Cloud Engineering
Flask app with professional Microsoft/McKinsey style UI
Connects to Microsoft Foundry Local at localhost:57055
Run: python local_ai_demo.py
Open: http://localhost:8501
"""
from flask import Flask, request, jsonify, render_template_string
from openai import OpenAI

app = Flask(__name__)

FOUNDRY_URL = "http://localhost:57055/v1"
FOUNDRY_KEY = "local"
MAX_TOKENS  = 380

MODELS = {
    "Phi-4 Mini · NPU":         "phi-4-mini-instruct-openvino-npu:3",
    "DeepSeek R1 7B · NPU":     "DeepSeek-R1-Distill-Qwen-7B-openvino-npu:3",
    "Mistral 7B · NPU":         "Mistral-7B-Instruct-v0-2-openvino-npu:2",
    "DeepSeek R1 1.5B · iGPU":  "DeepSeek-R1-Distill-Qwen-1.5B-openvino-gpu:2",
    "Qwen3 0.6B · CPU":         "qwen3-0.6b-generic-cpu:4",
}

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Local AI · Copilot+ PC Demo</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root {
  --bg:        #06080f;
  --bg1:       #0c1120;
  --bg2:       #111827;
  --bg3:       #1a2235;
  --border:    #1e2d45;
  --border2:   #253550;
  --navy:      #0f2044;
  --teal:      #0ea5c9;
  --teal-d:    #0c8baa;
  --teal-glow: rgba(14,165,201,0.12);
  --blue:      #3b82f6;
  --green:     #10b981;
  --amber:     #f59e0b;
  --red:       #ef4444;
  --purple:    #8b5cf6;
  --text:      #f0f4f8;
  --text2:     #94a3b8;
  --text3:     #475569;
  --text4:     #2d4060;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;font-size:14px;line-height:1.5}

/* ── Layout ─────────────────────────────────────────────────── */
.shell{display:flex;flex-direction:column;height:100vh}
.topbar{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 32px;height:58px;
  background:var(--bg1);
  border-bottom:1px solid var(--border);
  flex-shrink:0;
}
.main{display:flex;flex:1;overflow:hidden}
.sidebar{
  width:230px;flex-shrink:0;
  background:var(--bg1);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  padding:20px 0;
  overflow-y:auto;
}
.content{flex:1;overflow-y:auto;padding:28px 32px}

/* ── Topbar ─────────────────────────────────────────────────── */
.tb-left{display:flex;align-items:center;gap:12px}
.tb-logo{
  width:34px;height:34px;border-radius:8px;
  background:linear-gradient(135deg,#0ea5c9,#3b82f6);
  display:flex;align-items:center;justify-content:center;
  font-size:16px;flex-shrink:0;
}
.tb-title{font-size:15px;font-weight:700;color:var(--text);letter-spacing:-0.01em}
.tb-sub{font-size:11px;color:var(--text3);margin-top:1px}
.tb-badges{display:flex;gap:8px;align-items:center}
.badge{
  display:flex;align-items:center;gap:5px;
  border-radius:100px;padding:4px 12px;
  font-size:11px;font-weight:500;letter-spacing:0.01em;
  white-space:nowrap;
}
.badge-live{background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);color:#10b981}
.badge-npu{background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.25);color:#60a5fa}
.badge-private{background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);color:#fbbf24}
.live-dot{width:6px;height:6px;background:#10b981;border-radius:50%;animation:blink 2s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}

/* ── Sidebar ─────────────────────────────────────────────────── */
.sb-section{padding:0 16px;margin-bottom:6px}
.sb-label{font-size:10px;font-weight:600;color:var(--text3);text-transform:uppercase;letter-spacing:.1em;padding:0 12px;margin-bottom:6px}
.sb-item{
  display:flex;align-items:center;gap:10px;
  padding:9px 12px;border-radius:8px;
  cursor:pointer;transition:all .15s;
  font-size:13px;font-weight:500;color:var(--text2);
  border:1px solid transparent;
  margin-bottom:2px;
}
.sb-item:hover{background:var(--bg3);color:var(--text)}
.sb-item.active{background:var(--teal-glow);border-color:rgba(14,165,201,.25);color:var(--teal)}
.sb-icon{font-size:15px;width:20px;text-align:center}

.sb-divider{height:1px;background:var(--border);margin:12px 16px}

.sb-model-label{font-size:10px;font-weight:600;color:var(--text3);text-transform:uppercase;letter-spacing:.1em;padding:0 16px;margin-bottom:8px}
.sb-model-select{
  margin:0 12px;
  background:var(--bg3);
  border:1px solid var(--border2);
  border-radius:8px;
  color:var(--text);
  font-size:12px;
  padding:8px 10px;
  width:calc(100% - 24px);
  font-family:'Inter',sans-serif;
  outline:none;
  cursor:pointer;
}
.sb-model-select:focus{border-color:var(--teal)}

.sb-status{margin:auto 0 0;padding:16px}
.sb-status-row{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text3);margin-bottom:6px}
.dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.dot-green{background:#10b981}
.dot-red{background:#ef4444}
.dot-blue{background:#3b82f6}

/* ── Content ─────────────────────────────────────────────────── */
.page{display:none}
.page.active{display:block}

.page-header{margin-bottom:24px}
.page-title{font-size:22px;font-weight:700;color:var(--text);letter-spacing:-0.02em;margin-bottom:4px}
.page-sub{font-size:13px;color:var(--text2)}

.tool-layout{display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start}

/* ── Cards ───────────────────────────────────────────────────── */
.card{
  background:var(--bg2);
  border:1px solid var(--border);
  border-radius:14px;
  overflow:hidden;
}
.card-header{
  padding:16px 20px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-between;
}
.card-title{font-size:12px;font-weight:600;color:var(--text3);text-transform:uppercase;letter-spacing:.08em}
.card-model{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--text4)}
.card-body{padding:20px}

/* ── Form elements ───────────────────────────────────────────── */
label.field-label{display:block;font-size:11px;font-weight:600;color:var(--text3);text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}
select.field-select{
  width:100%;background:var(--bg1);border:1px solid var(--border2);
  border-radius:8px;color:var(--text);font-size:13px;padding:9px 12px;
  font-family:'Inter',sans-serif;outline:none;cursor:pointer;margin-bottom:14px;
  transition:border-color .15s;
}
select.field-select:focus{border-color:var(--teal)}
textarea.field-ta{
  width:100%;background:var(--bg1);border:1px solid var(--border2);
  border-radius:8px;color:var(--text);font-size:13px;padding:12px;
  font-family:'Inter',sans-serif;outline:none;resize:vertical;
  line-height:1.65;transition:border-color .15s;
}
textarea.field-ta:focus{border-color:var(--teal);box-shadow:0 0 0 3px rgba(14,165,201,.08)}
textarea.field-ta::placeholder{color:var(--text4)}

/* ── Run button ──────────────────────────────────────────────── */
.run-btn{
  width:100%;margin-top:14px;padding:12px;
  background:linear-gradient(135deg,#0ea5c9,#3b82f6);
  border:none;border-radius:9px;
  color:#fff;font-size:13px;font-weight:600;
  cursor:pointer;transition:opacity .15s;
  font-family:'Inter',sans-serif;letter-spacing:.01em;
}
.run-btn:hover{opacity:.88}
.run-btn:disabled{opacity:.45;cursor:not-allowed}

/* ── Output area ─────────────────────────────────────────────── */
.output-wrap{display:flex;flex-direction:column;gap:0}
.output-header{
  padding:12px 18px;
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-between;
}
.output-header-title{font-size:11px;font-weight:600;color:var(--text3);text-transform:uppercase;letter-spacing:.08em}
.output-body{
  padding:18px;min-height:180px;
  font-size:13px;line-height:1.75;color:#cbd5e1;
  white-space:pre-wrap;word-break:break-word;
}
.output-body.empty{color:var(--text4);font-style:italic}
.output-footer{
  padding:10px 18px;
  border-top:1px solid var(--border);
  display:flex;align-items:center;gap:6px;
  font-size:11px;
}
.output-footer.idle{color:var(--text4)}
.output-footer.done{color:#065f46}
.output-footer .footer-dot{width:6px;height:6px;background:#10b981;border-radius:50%}

/* ── Spinner ─────────────────────────────────────────────────── */
.spinner{display:none;align-items:center;gap:10px;padding:18px;font-size:13px;color:var(--text2)}
.spinner.show{display:flex}
.spin-ring{
  width:18px;height:18px;border-radius:50%;flex-shrink:0;
  border:2px solid var(--border2);border-top-color:var(--teal);
  animation:spin .8s linear infinite;
}
@keyframes spin{to{transform:rotate(360deg)}}

/* ── Chat ────────────────────────────────────────────────────── */
.chat-wrap{display:flex;flex-direction:column;height:calc(100vh - 220px);min-height:400px}
.chat-messages{flex:1;overflow-y:auto;padding:4px 0;display:flex;flex-direction:column;gap:12px}
.chat-msg{display:flex;gap:12px;align-items:flex-start}
.chat-msg.user{flex-direction:row-reverse}
.chat-avatar{
  width:32px;height:32px;border-radius:8px;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;font-size:14px;
}
.chat-avatar.ai{background:linear-gradient(135deg,#0ea5c9,#3b82f6)}
.chat-avatar.user{background:var(--bg3);border:1px solid var(--border2)}
.chat-bubble{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:12px;padding:12px 16px;
  max-width:80%;font-size:13px;line-height:1.7;color:#cbd5e1;
}
.chat-msg.user .chat-bubble{background:var(--teal-glow);border-color:rgba(14,165,201,.2);color:var(--text)}
.chat-input-row{display:flex;gap:10px;margin-top:16px;align-items:flex-end}
.chat-ta{
  flex:1;background:var(--bg1);border:1px solid var(--border2);
  border-radius:10px;color:var(--text);font-size:13px;
  padding:11px 14px;font-family:'Inter',sans-serif;outline:none;
  resize:none;line-height:1.5;
}
.chat-ta:focus{border-color:var(--teal)}
.chat-send{
  padding:11px 20px;background:linear-gradient(135deg,#0ea5c9,#3b82f6);
  border:none;border-radius:10px;color:#fff;font-size:13px;
  font-weight:600;cursor:pointer;font-family:'Inter',sans-serif;
  white-space:nowrap;flex-shrink:0;
}
.chat-send:hover{opacity:.88}
.chat-clear{
  padding:11px 14px;background:var(--bg3);border:1px solid var(--border2);
  border-radius:10px;color:var(--text2);font-size:13px;
  cursor:pointer;font-family:'Inter',sans-serif;white-space:nowrap;flex-shrink:0;
}
.chat-clear:hover{border-color:var(--border);color:var(--text)}

/* ── Status bar ──────────────────────────────────────────────── */
.status-bar{
  display:flex;gap:20px;align-items:center;
  padding:12px 20px;margin-top:24px;
  background:var(--bg1);border:1px solid var(--border);border-radius:10px;
  font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text4);
  flex-wrap:wrap;
}
.status-item{display:flex;align-items:center;gap:6px}
.status-item .no-cloud{color:#ef4444}
</style>
</head>
<body>
<div class="shell">

<!-- ── TOPBAR ─────────────────────────────────────────────── -->
<div class="topbar">
  <div class="tb-left">
    <div class="tb-logo">⚡</div>
    <div>
      <div class="tb-title">Local AI Demo</div>
      <div class="tb-sub">TD SYNNEX Cloud Engineering · Copilot+ PC</div>
    </div>
  </div>
  <div class="tb-badges">
    <div class="badge badge-live"><div class="live-dot"></div>NPU Active</div>
    <div class="badge badge-npu">Intel Core Ultra · 40+ TOPS</div>
    <div class="badge badge-private">🔒 100% On-Device</div>
  </div>
</div>

<div class="main">

<!-- ── SIDEBAR ────────────────────────────────────────────── -->
<div class="sidebar">
  <div class="sb-section">
    <div class="sb-label">Tools</div>
    <div class="sb-item active" onclick="nav('email',this)"><span class="sb-icon">✉️</span>Email Rewriter</div>
    <div class="sb-item" onclick="nav('pii',this)"><span class="sb-icon">🔒</span>PII Detector</div>
    <div class="sb-item" onclick="nav('summary',this)"><span class="sb-icon">📋</span>Summarizer</div>
    <div class="sb-item" onclick="nav('ticket',this)"><span class="sb-icon">🏷️</span>Ticket Triage</div>
    <div class="sb-item" onclick="nav('tone',this)"><span class="sb-icon">📝</span>Tone Fixer</div>
    <div class="sb-item" onclick="nav('chat',this)"><span class="sb-icon">💬</span>Free Chat</div>
  </div>

  <div class="sb-divider"></div>

  <div class="sb-model-label">Active Model</div>
  <select class="sb-model-select" id="modelSelect">
    <option value="phi-4-mini-instruct-openvino-npu:3">Phi-4 Mini · NPU</option>
    <option value="DeepSeek-R1-Distill-Qwen-7B-openvino-npu:3">DeepSeek R1 7B · NPU</option>
    <option value="Mistral-7B-Instruct-v0-2-openvino-npu:2">Mistral 7B · NPU</option>
    <option value="DeepSeek-R1-Distill-Qwen-1.5B-openvino-gpu:2">DeepSeek R1 1.5B · iGPU</option>
    <option value="qwen3-0.6b-generic-cpu:4">Qwen3 0.6B · CPU</option>
  </select>

  <div class="sb-status">
    <div class="sb-status-row"><div class="dot dot-green"></div>Foundry Local · :57055</div>
    <div class="sb-status-row"><div class="dot dot-green"></div>Microsoft Foundry SDK</div>
    <div class="sb-status-row"><div class="dot dot-red"></div>No Cloud Connection</div>
    <div class="sb-status-row"><div class="dot dot-blue"></div>Intel NPU Driver Active</div>
  </div>
</div>

<!-- ── CONTENT ────────────────────────────────────────────── -->
<div class="content">

<!-- EMAIL -->
<div id="page-email" class="page active">
  <div class="page-header">
    <div class="page-title">✉️ Email Rewriter</div>
    <div class="page-sub">Paste a rough draft — get back a polished version. Confidential emails never leave this device.</div>
  </div>
  <div class="tool-layout">
    <div class="card">
      <div class="card-header"><span class="card-title">Input</span></div>
      <div class="card-body">
        <label class="field-label">Tone</label>
        <select class="field-select" id="e-tone">
          <option>Professional</option>
          <option>Friendly & Warm</option>
          <option>Executive / Concise</option>
          <option>Partner-Facing (Microsoft)</option>
        </select>
        <label class="field-label">Draft Email</label>
        <textarea class="field-ta" id="e-input" rows="8" placeholder="Hey just checking if you got my email about the renewal. We really need an answer soon or its going to be a problem..."></textarea>
        <button class="run-btn" onclick="runTool('email')">✨  Rewrite Email</button>
      </div>
    </div>
    <div class="card output-wrap">
      <div class="output-header">
        <span class="output-header-title">Rewritten Email</span>
        <span class="output-model" id="e-model-label"></span>
      </div>
      <div class="spinner" id="e-spinner"><div class="spin-ring"></div>Processing on NPU...</div>
      <div class="output-body empty" id="e-output">Rewritten email will appear here.</div>
      <div class="output-footer idle" id="e-footer"><span>Waiting for input...</span></div>
    </div>
  </div>
  <div class="status-bar" id="e-status-bar" style="display:none"></div>
</div>

<!-- PII -->
<div id="page-pii" class="page">
  <div class="page-header">
    <div class="page-title">🔒 PII Detector</div>
    <div class="page-sub">Flags personally identifiable information with risk levels. Built for healthcare, legal, and financial SMBs. Zero data leaves the device.</div>
  </div>
  <div class="tool-layout">
    <div class="card">
      <div class="card-header"><span class="card-title">Input</span></div>
      <div class="card-body">
        <label class="field-label">Text to Scan</label>
        <textarea class="field-ta" id="p-input" rows="12" placeholder="Patient: John Smith, DOB: 03/15/1978, SSN: 463-79-2298&#10;Email: jsmith@gmail.com, Phone: (512) 555-0142&#10;Diagnosis: Type 2 Diabetes, Account: BCX-99210"></textarea>
        <button class="run-btn" onclick="runTool('pii')">🔍  Scan for PII</button>
      </div>
    </div>
    <div class="card output-wrap">
      <div class="output-header">
        <span class="output-header-title">PII Analysis</span>
        <span class="output-model" id="p-model-label"></span>
      </div>
      <div class="spinner" id="p-spinner"><div class="spin-ring"></div>Scanning on NPU...</div>
      <div class="output-body empty" id="p-output">PII analysis will appear here.</div>
      <div class="output-footer idle" id="p-footer"><span>Waiting for input...</span></div>
    </div>
  </div>
</div>

<!-- SUMMARIZER -->
<div id="page-summary" class="page">
  <div class="page-header">
    <div class="page-title">📋 Document Summarizer</div>
    <div class="page-sub">Paste meeting notes, email threads, contracts, or articles. Get a tight, structured summary instantly.</div>
  </div>
  <div class="tool-layout">
    <div class="card">
      <div class="card-header"><span class="card-title">Input</span></div>
      <div class="card-body">
        <label class="field-label">Format</label>
        <select class="field-select" id="s-fmt">
          <option>3-Bullet Executive Summary</option>
          <option>Action Items Only</option>
          <option>Key Facts (numbered list)</option>
          <option>BLUF — Bottom Line Up Front</option>
        </select>
        <label class="field-label">Content to Summarize</label>
        <textarea class="field-ta" id="s-input" rows="8" placeholder="Paste meeting notes, an email thread, a contract clause, or any business document..."></textarea>
        <button class="run-btn" onclick="runTool('summary')">📋  Summarize</button>
      </div>
    </div>
    <div class="card output-wrap">
      <div class="output-header">
        <span class="output-header-title">Summary</span>
        <span class="output-model" id="s-model-label"></span>
      </div>
      <div class="spinner" id="s-spinner"><div class="spin-ring"></div>Summarizing on NPU...</div>
      <div class="output-body empty" id="s-output">Summary will appear here.</div>
      <div class="output-footer idle" id="s-footer"><span>Waiting for input...</span></div>
    </div>
  </div>
</div>

<!-- TICKET -->
<div id="page-ticket" class="page">
  <div class="page-header">
    <div class="page-title">🏷️ Support Ticket Triage</div>
    <div class="page-sub">Paste a customer message — AI categorizes it, assigns priority, drafts a customer reply, and adds an internal tech note. Perfect for MSPs.</div>
  </div>
  <div class="tool-layout">
    <div class="card">
      <div class="card-header"><span class="card-title">Input</span></div>
      <div class="card-body">
        <label class="field-label">Customer Message or Ticket</label>
        <textarea class="field-ta" id="t-input" rows="12" placeholder="Hi, I can't log into my email since this morning. I have a client presentation in 2 hours and really need access urgently. My username is jdoe@acme.com."></textarea>
        <button class="run-btn" onclick="runTool('ticket')">🏷️  Triage Ticket</button>
      </div>
    </div>
    <div class="card output-wrap">
      <div class="output-header">
        <span class="output-header-title">Triage Result</span>
        <span class="output-model" id="t-model-label"></span>
      </div>
      <div class="spinner" id="t-spinner"><div class="spin-ring"></div>Triaging on NPU...</div>
      <div class="output-body empty" id="t-output">Triage result will appear here.</div>
      <div class="output-footer idle" id="t-footer"><span>Waiting for input...</span></div>
    </div>
  </div>
</div>

<!-- TONE -->
<div id="page-tone" class="page">
  <div class="page-header">
    <div class="page-title">📝 Tone & Grammar Fixer</div>
    <div class="page-sub">Fix grammar, sharpen clarity, adjust tone. Great for sales reps, partner communications, and customer-facing content.</div>
  </div>
  <div class="tool-layout">
    <div class="card">
      <div class="card-header"><span class="card-title">Input</span></div>
      <div class="card-body">
        <label class="field-label">Fix Mode</label>
        <select class="field-select" id="tf-mode">
          <option>Fix Grammar & Clarity</option>
          <option>Make More Professional</option>
          <option>Make More Concise (50% shorter)</option>
          <option>Soften the Tone</option>
          <option>Partner-Facing (Microsoft ecosystem)</option>
        </select>
        <label class="field-label">Text to Fix</label>
        <textarea class="field-ta" id="tf-input" rows="8" placeholder="we been trying to reach you about the renewal and honestly if we dont hear back soon were going to have to escalate this to management its been 3 weeks"></textarea>
        <button class="run-btn" onclick="runTool('tone')">✏️  Fix It</button>
      </div>
    </div>
    <div class="card output-wrap">
      <div class="output-header">
        <span class="output-header-title">Fixed Version</span>
        <span class="output-model" id="tf-model-label"></span>
      </div>
      <div class="spinner" id="tf-spinner"><div class="spin-ring"></div>Fixing on NPU...</div>
      <div class="output-body empty" id="tf-output">Fixed text will appear here.</div>
      <div class="output-footer idle" id="tf-footer"><span>Waiting for input...</span></div>
    </div>
  </div>
</div>

<!-- CHAT -->
<div id="page-chat" class="page">
  <div class="page-header">
    <div class="page-title">💬 Free Chat</div>
    <div class="page-sub">Open conversation. One focused topic per session gives best results with on-device models.</div>
  </div>
  <div class="card" style="padding:20px">
    <div class="chat-wrap">
      <div class="chat-messages" id="chat-messages">
        <div class="chat-msg">
          <div class="chat-avatar ai">⚡</div>
          <div class="chat-bubble">Hi! I'm running locally on your Intel Core Ultra NPU — no cloud, no API keys, no data leaving this device. Ask me anything.</div>
        </div>
      </div>
      <div class="chat-input-row">
        <textarea class="chat-ta" id="chat-input" rows="2" placeholder="Ask anything..."></textarea>
        <button class="chat-clear" onclick="clearChat()">🗑️ Clear</button>
        <button class="chat-send" onclick="sendChat()">Send →</button>
      </div>
    </div>
  </div>
</div>

</div><!-- /content -->
</div><!-- /main -->
</div><!-- /shell -->

<script>
let chatHistory = [];

// Navigation
function nav(page, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.sb-item').forEach(i => i.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  el.classList.add('active');
}

// Get current model
function getModel() {
  return document.getElementById('modelSelect').value;
}
function getModelShort() {
  return getModel().split(':')[0].slice(-38);
}

// Generic tool runner
async function runTool(tool) {
  const configs = {
    email: {
      inputId: 'e-input',
      outputId: 'e-output',
      spinnerId: 'e-spinner',
      footerId: 'e-footer',
      modelId: 'e-model-label',
      getPayload: () => ({
        system: `You are a professional business writing expert. Rewrite the email in a ${document.getElementById('e-tone').value.toLowerCase()} tone. Under 120 words. Output ONLY the rewritten email, no preamble.`,
        user: document.getElementById('e-input').value
      })
    },
    pii: {
      inputId: 'p-input', outputId: 'p-output', spinnerId: 'p-spinner',
      footerId: 'p-footer', modelId: 'p-model-label',
      getPayload: () => ({
        system: `You are a data privacy compliance officer. Scan the text for PII (Personally Identifiable Information).
Return ONLY this exact format:
FOUND PII:
• [Type]: [Value] — [HIGH / MED / LOW]

SUMMARY: [One sentence compliance action required.]`,
        user: document.getElementById('p-input').value
      })
    },
    summary: {
      inputId: 's-input', outputId: 's-output', spinnerId: 's-spinner',
      footerId: 's-footer', modelId: 's-model-label',
      getPayload: () => {
        const fmts = {
          '3-Bullet Executive Summary': 'Summarize in exactly 3 bullets. Max 20 words each. Start each with •',
          'Action Items Only': 'Extract ONLY action items. Format: ACTION → [who] → [what] → [deadline if mentioned]',
          'Key Facts (numbered list)': 'Extract 5 key facts as a numbered list. One sentence each.',
          'BLUF — Bottom Line Up Front': 'BLUF: [one sentence bottom line]. Then 2-3 supporting points.'
        };
        const fmt = document.getElementById('s-fmt').value;
        return { system: `You are a concise analyst. ${fmts[fmt]} Output ONLY the summary.`, user: document.getElementById('s-input').value };
      }
    },
    ticket: {
      inputId: 't-input', outputId: 't-output', spinnerId: 't-spinner',
      footerId: 't-footer', modelId: 't-model-label',
      getPayload: () => ({
        system: `You are an IT help desk triage specialist. Analyze this support ticket.
Return ONLY this format:
CATEGORY: [Access/Auth | Hardware | Software | Network | Billing | General]
PRIORITY: [CRITICAL | HIGH | MEDIUM | LOW]
REASON: [One sentence.]
RESPONSE TO CUSTOMER: [2 sentence professional reply.]
INTERNAL NOTE: [One sentence for the technician.]`,
        user: document.getElementById('t-input').value
      })
    },
    tone: {
      inputId: 'tf-input', outputId: 'tf-output', spinnerId: 'tf-spinner',
      footerId: 'tf-footer', modelId: 'tf-model-label',
      getPayload: () => {
        const modes = {
          'Fix Grammar & Clarity': 'Fix all grammar, punctuation, and clarity. Keep the same meaning and approximate length.',
          'Make More Professional': 'Rewrite professionally and formally. Keep under 100 words.',
          'Make More Concise (50% shorter)': 'Rewrite at half the length. Keep all key information.',
          'Soften the Tone': 'Rewrite to be collaborative and non-confrontational. Keep the message.',
          'Partner-Facing (Microsoft ecosystem)': 'Rewrite for a Microsoft partner audience. Solution-focused, concise, professional.'
        };
        const mode = document.getElementById('tf-mode').value;
        return { system: `You are a professional editor. ${modes[mode]} Output ONLY the rewritten text.`, user: document.getElementById('tf-input').value };
      }
    }
  };

  const cfg = configs[tool];
  const payload = cfg.getPayload();
  if (!payload.user.trim()) { alert('Please enter some text first.'); return; }

  // UI: loading state
  const out = document.getElementById(cfg.outputId);
  const spin = document.getElementById(cfg.spinnerId);
  const foot = document.getElementById(cfg.footerId);
  const ml = document.getElementById(cfg.modelId);

  out.style.display = 'none';
  spin.classList.add('show');
  foot.innerHTML = '<span>Processing on NPU...</span>';
  foot.className = 'output-footer idle';
  ml.textContent = getModelShort();

  try {
    const res = await fetch('/api/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: getModel(), system: payload.system, user: payload.user })
    });
    const data = await res.json();
    spin.classList.remove('show');
    out.style.display = 'block';
    out.textContent = data.result || data.error;
    out.className = 'output-body';
    foot.innerHTML = '<div class="footer-dot"></div>Processed on-device · No data sent to cloud';
    foot.className = 'output-footer done';
  } catch(e) {
    spin.classList.remove('show');
    out.style.display = 'block';
    out.textContent = 'Connection error. Make sure Foundry Local is running:\nfoundry service start\nfoundry model load phi-4-mini';
    out.className = 'output-body';
  }
}

// Chat
async function sendChat() {
  const ta = document.getElementById('chat-input');
  const msg = ta.value.trim();
  if (!msg) return;
  ta.value = '';

  appendChat('user', msg);
  chatHistory.push({ role: 'user', content: msg });

  // Keep last 6 messages to avoid context overflow
  const recent = chatHistory.slice(-6);

  appendChat('ai', '...');
  const bubbles = document.querySelectorAll('#chat-messages .chat-bubble');
  const lastBubble = bubbles[bubbles.length - 1];

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: getModel(), messages: recent })
    });
    const data = await res.json();
    lastBubble.textContent = data.result || data.error;
    chatHistory.push({ role: 'assistant', content: data.result || data.error });
  } catch(e) {
    lastBubble.textContent = 'Error connecting to Foundry Local.';
  }

  // Scroll to bottom
  const cm = document.getElementById('chat-messages');
  cm.scrollTop = cm.scrollHeight;
}

function appendChat(role, text) {
  const cm = document.getElementById('chat-messages');
  const isUser = role === 'user';
  cm.innerHTML += `
    <div class="chat-msg ${isUser ? 'user' : ''}">
      <div class="chat-avatar ${isUser ? 'user' : 'ai'}">${isUser ? '👤' : '⚡'}</div>
      <div class="chat-bubble">${text}</div>
    </div>`;
  cm.scrollTop = cm.scrollHeight;
}

function clearChat() {
  chatHistory = [];
  document.getElementById('chat-messages').innerHTML = `
    <div class="chat-msg">
      <div class="chat-avatar ai">⚡</div>
      <div class="chat-bubble">Chat cleared. Running locally on your Intel Core Ultra NPU — ask me anything.</div>
    </div>`;
}

// Enter key in chat
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('chat-input').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); }
  });
});
</script>
</body>
</html>"""

def call_foundry(model: str, system: str, user: str) -> str:
    client = OpenAI(base_url=FOUNDRY_URL, api_key=FOUNDRY_KEY)
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
        max_tokens=MAX_TOKENS,
        temperature=0.3,
    )
    return resp.choices[0].message.content.strip()

@app.route("/")
def index():
    return render_template_string(HTML)

@app.route("/api/run", methods=["POST"])
def api_run():
    data = request.json
    try:
        result = call_foundry(data["model"], data["system"], data["user"])
        return jsonify({"result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/chat", methods=["POST"])
def api_chat():
    data = request.json
    try:
        client = OpenAI(base_url=FOUNDRY_URL, api_key=FOUNDRY_KEY)
        system = "You are a helpful, concise assistant. Keep responses under 200 words unless asked for more."
        messages = [{"role": "system", "content": system}] + data["messages"]
        resp = client.chat.completions.create(
            model=data["model"],
            messages=messages,
            max_tokens=MAX_TOKENS,
            temperature=0.4,
        )
        return jsonify({"result": resp.choices[0].message.content.strip()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    print("\n" + "="*52)
    print("  Local AI Demo · TD SYNNEX Cloud Engineering")
    print("  Running at: http://localhost:8501")
    print("  Foundry Local: http://localhost:57055")
    print("="*52 + "\n")
    app.run(host="0.0.0.0", port=8501, debug=False)
