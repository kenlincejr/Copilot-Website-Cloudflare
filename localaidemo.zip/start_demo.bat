@echo off
echo Starting Local AI Demo Stack...
echo.

cd C:\windows\system32\surface-npu-demo
call venv\Scripts\activate

echo [1/4] Starting Foundry Local engine...
foundry service start

echo [2/4] Loading Phi-4 Mini onto NPU...
foundry model load phi-4-mini

echo [3/4] Starting keepalive (prevents idle timeout)...
start "Keepalive" cmd /k "cd C:\windows\system32\surface-npu-demo && venv\Scripts\activate && python keepalive.py"

echo [4/4] Launching demo app and Open WebUI...
start "Demo App 8501" cmd /k "cd C:\windows\system32\surface-npu-demo && venv\Scripts\activate && python local_ai_demo.py"
start "Open WebUI 3000" cmd /k "cd C:\windows\system32\surface-npu-demo && venv\Scripts\activate && open-webui serve --port 3000"

echo.
echo Waiting for services to start (8 seconds)...
timeout /t 8 /nobreak >nul

echo Opening browser tabs...
start "" "http://localhost:8501"
timeout /t 3 /nobreak >nul
start "" "http://localhost:3000"

echo.
echo =============================================
echo   Demo stack is LIVE
echo   localhost:8501  - SMB Tool Demo App
echo   localhost:3000  - Open WebUI Chat
echo =============================================
echo.
echo TO SHUT DOWN CLEANLY:
echo   1. Close Keepalive, Demo App, Open WebUI windows
echo   2. Run: foundry service stop
echo   3. Close this window
echo.
pause
