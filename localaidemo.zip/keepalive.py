"""
Foundry Local Keepalive
Sends a lightweight ping to the model every 4 minutes
to prevent the 10-minute idle timeout from unloading it.
Run: python keepalive.py
Leave running in the background during demos.
"""
import time
import datetime
from openai import OpenAI

FOUNDRY_URL = "http://localhost:57055/v1"
FOUNDRY_KEY = "local"
MODEL       = "phi-4-mini-instruct-openvino-npu:3"
INTERVAL    = 240  # seconds (4 minutes — safely under the 10-min timeout)

client = OpenAI(base_url=FOUNDRY_URL, api_key=FOUNDRY_KEY)

def ping():
    resp = client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": "ok"}],
        max_tokens=5,
        temperature=0,
    )
    return resp.choices[0].message.content.strip()

print("=" * 48)
print("  Foundry Local Keepalive — Model stays hot")
print(f"  Pinging every {INTERVAL//60} minutes. Ctrl+C to stop.")
print("=" * 48)

while True:
    try:
        result = ping()
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] ✓ Model alive — response: '{result}'")
    except Exception as e:
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] ✗ Ping failed: {e}")
        print("       Check: foundry service status")
    time.sleep(INTERVAL)
